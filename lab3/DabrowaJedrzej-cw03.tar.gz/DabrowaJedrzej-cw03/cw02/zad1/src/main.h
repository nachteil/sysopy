#ifndef SYSOPY_MAIN_H
#define SYSOPY_MAIN_H

void do_fork(int);
void do_vfork(int);
void do_fork_clone(int);
void do_vfork_clone(int);
int function(void*);

#endif //SYSOPY_MAIN_H

#ifndef SYSOPY_RDFIFO_H
#define SYSOPY_RDFIFO_H

void extract_pid(char *, char *);
void extract_write_date(char *, char *);
void extract_msg(char *, char *);

#endif //SYSOPY_RDFIFO_H

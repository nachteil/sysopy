#ifndef SYSOPY_FILE_COUNTER_H
#define SYSOPY_FILE_COUNTER_H

void usage(void);

#endif //SYSOPY_FILE_COUNTER_H

#ifndef SYSOPY_CHILD_H
#define SYSOPY_CHILD_H
#define _GNU_SOURCE

void sig_handle(int);

#endif //SYSOPY_CHILD_H

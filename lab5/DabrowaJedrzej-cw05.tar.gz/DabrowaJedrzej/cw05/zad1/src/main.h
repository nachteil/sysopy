#ifndef SYSOPY_MAIN_H
#define SYSOPY_MAIN_H
#define _GNU_SOURCE

#include "sys/stat.h"
char *get_access(struct stat *);

#endif //SYSOPY_MAIN_H

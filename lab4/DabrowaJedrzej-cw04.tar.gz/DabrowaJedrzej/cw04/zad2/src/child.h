#ifndef SYSOPY_CHILD_H
#define SYSOPY_CHILD_H
#define _GNU_SOURCE

void sig_handle(int);
void sig_handle_sender(int);

#endif //SYSOPY_CHILD_H

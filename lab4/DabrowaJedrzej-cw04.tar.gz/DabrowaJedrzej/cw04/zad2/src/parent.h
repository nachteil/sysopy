#ifndef SYSOPY_PARENT_H
#define SYSOPY_PARENT_H
void sig_handle_sender(int);
void sig_handle_receiver(int);
#endif //SYSOPY_PARENT_H

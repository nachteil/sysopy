#include "list_funs.h"
#include "list_structs.h"
#include "time.h"

int main(int, char *argv[]);
list_t * create_sample_list();
void print_time();
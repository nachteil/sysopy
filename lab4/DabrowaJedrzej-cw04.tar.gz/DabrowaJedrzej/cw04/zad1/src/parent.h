#ifndef SYSOPY_PARENT_H
#define SYSOPY_PARENT_H
void sig_handle(int);
#endif //SYSOPY_PARENT_H
